
from fastapi import FastAPI
from pydantic import BaseModel
from agents.supervisor_agent import SupervisorAgent

app = FastAPI()

supervisor = SupervisorAgent()

class ChatRequest(BaseModel):
    user_id: str
    message: str

@app.post("/chat")
async def chat(req: ChatRequest):
    result = supervisor.run(req.user_id, req.message)
    return result
