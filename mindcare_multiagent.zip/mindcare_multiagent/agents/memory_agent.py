
import json
from pathlib import Path

class MemoryAgent:

    def __init__(self):
        self.memory_dir = Path("memory")
        self.memory_dir.mkdir(exist_ok=True)

    def update(self, user_id, data):

        file_path = self.memory_dir / f"{user_id}.json"

        history = []

        if file_path.exists():
            history = json.loads(file_path.read_text(encoding="utf-8"))

        history.append(data)

        file_path.write_text(
            json.dumps(history, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

        return {
            "history_count": len(history)
        }
