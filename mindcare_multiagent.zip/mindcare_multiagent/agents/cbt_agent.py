
class CBTAgent:

    def generate_support(self, emotion_result):

        emotions = emotion_result["emotions"]

        if "anxiety" in emotions:
            return (
                "你当前可能处于较强焦虑状态。"
                "建议尝试4-7-8呼吸法，并将当前压力事件拆分成可执行的小步骤。"
            )

        if "sadness" in emotions:
            return (
                "你现在可能积累了较多负面情绪。"
                "尝试记录今天发生的一件积极小事，有助于打破负向思维循环。"
            )

        return "感谢你的分享，持续表达情绪本身就是一种积极行为。"
