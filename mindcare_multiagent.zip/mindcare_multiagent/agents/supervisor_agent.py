
from agents.emotion_agent import EmotionAgent
from agents.risk_agent import RiskAgent
from agents.cbt_agent import CBTAgent
from agents.memory_agent import MemoryAgent
from agents.resource_agent import ResourceAgent

class SupervisorAgent:

    def __init__(self):

        self.emotion_agent = EmotionAgent()
        self.risk_agent = RiskAgent()
        self.cbt_agent = CBTAgent()
        self.memory_agent = MemoryAgent()
        self.resource_agent = ResourceAgent()

    def run(self, user_id, text):

        emotion_result = self.emotion_agent.analyze(text)

        risk_result = self.risk_agent.analyze(text)

        support_text = self.cbt_agent.generate_support(
            emotion_result
        )

        memory_result = self.memory_agent.update(
            user_id,
            {
                "message": text,
                "emotion": emotion_result,
                "risk": risk_result
            }
        )

        resources = self.resource_agent.recommend(
            emotion_result
        )

        final_reply = {
            "emotion_analysis": emotion_result,
            "risk_analysis": risk_result,
            "support_response": support_text,
            "resources": resources,
            "memory": memory_result
        }

        if risk_result["risk_level"] == "HIGH":
            final_reply["emergency"] = (
                "检测到高风险情绪，请尽快联系专业心理咨询人员或当地心理援助热线。"
            )

        return final_reply
