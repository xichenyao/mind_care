
class RiskAgent:

    HIGH_RISK_WORDS = [
        "自杀",
        "不想活",
        "结束生命",
        "割腕",
        "轻生"
    ]

    def analyze(self, text: str):

        for word in self.HIGH_RISK_WORDS:
            if word in text:
                return {
                    "risk_level": "HIGH",
                    "trigger": word
                }

        return {
            "risk_level": "LOW",
            "trigger": None
        }
