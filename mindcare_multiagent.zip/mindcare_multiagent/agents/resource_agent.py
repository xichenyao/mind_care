
class ResourceAgent:

    def recommend(self, emotion_result):

        emotions = emotion_result["emotions"]

        resources = []

        if "stress" in emotions:
            resources.append("番茄工作法")
            resources.append("正念呼吸训练")

        if "anxiety" in emotions:
            resources.append("睡眠冥想音频")
            resources.append("焦虑缓解训练")

        if "sadness" in emotions:
            resources.append("情绪记录日记")

        return resources
