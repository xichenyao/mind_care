
class EmotionAgent:

    def analyze(self, text: str):
        emotions = []

        if any(word in text for word in ["难过", "压抑", "痛苦"]):
            emotions.append("sadness")

        if any(word in text for word in ["焦虑", "害怕", "紧张"]):
            emotions.append("anxiety")

        if any(word in text for word in ["压力", "崩溃"]):
            emotions.append("stress")

        intensity = min(len(text) // 20 + len(emotions), 5)

        return {
            "emotions": emotions,
            "intensity": intensity
        }
